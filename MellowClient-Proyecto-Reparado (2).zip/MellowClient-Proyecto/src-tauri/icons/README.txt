Coloca aquí los iconos de Windows para el bundle de Tauri cuando estén disponibles.
