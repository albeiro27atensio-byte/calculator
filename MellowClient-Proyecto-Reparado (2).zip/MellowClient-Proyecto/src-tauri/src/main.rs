#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde_json::{json, Value};
use std::{fs, path::PathBuf};
use tauri::{AppHandle, Manager};

fn data_file(app: &AppHandle, name: &str) -> Result<PathBuf, String> {
    let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir.join(name))
}
fn read_json(app: &AppHandle, name: &str, fallback: Value) -> Value {
    data_file(app, name).ok().and_then(|p| fs::read_to_string(p).ok())
        .and_then(|s| serde_json::from_str(&s).ok()).unwrap_or(fallback)
}
fn write_json(app: &AppHandle, name: &str, value: &Value) -> Result<(), String> {
    let p = data_file(app, name)?;
    let bytes = serde_json::to_vec_pretty(value).map_err(|e| e.to_string())?;
    fs::write(p, bytes).map_err(|e| e.to_string())
}

#[tauri::command]
fn call(app: AppHandle, command: String, args: Value) -> Result<Value, String> {
    match command.as_str() {
        "versions" => Ok(json!(["1.21.11", "1.21.10", "1.21.9", "1.21.8", "1.21.7", "1.21.6", "1.21.5", "1.21.4", "1.21.3", "1.21.1", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.19.2", "1.18.2", "1.17.1", "1.16.5", "1.12.2", "1.8.9"])),
        "settings:save" => { write_json(&app, "settings.json", &args)?; Ok(json!({"ok":true})) },
        "settings:load" => Ok(read_json(&app, "settings.json", json!({}))),
        "acc:list" => Ok(read_json(&app, "accounts.json", json!([]))),
        "acc:add" | "acc:use" => Err("El inicio de sesión de Microsoft aún no está integrado. No se ha guardado ninguna cuenta.".into()),
        "acc:del" => {
            let id = args.get("id").and_then(Value::as_str).unwrap_or_default();
            let mut list = read_json(&app, "accounts.json", json!([]));
            if let Some(a) = list.as_array_mut() { a.retain(|v| v.get("id").and_then(Value::as_str) != Some(id)); }
            write_json(&app, "accounts.json", &list)?; Ok(list)
        },
        "mods:list" => {
            let root = args.get("root").and_then(Value::as_str).filter(|s| !s.is_empty()).map(PathBuf::from)
                .unwrap_or_else(|| dirs_fallback().join(".minecraft"));
            let dir = root.join("mods");
            let mut mods = Vec::new();
            if dir.exists() { if let Ok(entries) = fs::read_dir(dir) { for entry in entries.flatten() {
                let path = entry.path();
                if path.is_file() && path.extension().and_then(|x| x.to_str()).map(|x| x.eq_ignore_ascii_case("jar")).unwrap_or(false) {
                    let name = path.file_stem().and_then(|x| x.to_str()).unwrap_or("Mod").to_string();
                    mods.push(json!({"id":name,"name":name,"file":path.to_string_lossy(),"enabled":true}));
                }
            } } }
            Ok(Value::Array(mods))
        },
        "mods:search" => Ok(json!({"hits":[], "message":"La búsqueda en Modrinth requiere integrar el servicio de catálogo."})),
        "srv:list" => { let list = read_json(&app, "servers.json", json!([])); Ok(json!({"list":list,"ip":"127.0.0.1","maxram":8192,"domain":"localhost"})) },
        "srv:create" => {
            let mut list = read_json(&app, "servers.json", json!([]));
            let id = format!("srv-{}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_millis());
            let mut item = args.clone();
            if let Some(o) = item.as_object_mut() { o.insert("id".into(), json!(id)); o.insert("running".into(), json!(false)); }
            if let Some(a) = list.as_array_mut() { a.push(item); }
            write_json(&app, "servers.json", &list)?; Ok(json!({"list":list,"id":id}))
        },
        "srv:save" => {
            let mut list = read_json(&app, "servers.json", json!([]));
            let id = args.get("id").and_then(Value::as_str).unwrap_or_default();
            if let (Some(items), Some(update)) = (list.as_array_mut(), args.as_object()) {
                if let Some(item) = items.iter_mut().find(|v| v.get("id").and_then(Value::as_str) == Some(id)) {
                    if let Some(target) = item.as_object_mut() { for (k,v) in update { target.insert(k.clone(), v.clone()); } }
                }
            }
            write_json(&app, "servers.json", &list)?; Ok(json!({"list":list}))
        },
        "srv:del" => {
            let id = args.get("id").and_then(Value::as_str).unwrap_or_default();
            let mut list = read_json(&app, "servers.json", json!([]));
            if let Some(a) = list.as_array_mut() { a.retain(|v| v.get("id").and_then(Value::as_str) != Some(id)); }
            write_json(&app, "servers.json", &list)?; Ok(json!({"list":list}))
        },
        "win" => {
            let action = args.as_str().unwrap_or_default();
            let win = app.get_webview_window("main").ok_or("No se encontró la ventana principal")?;
            match action { "min" => win.minimize().map_err(|e|e.to_string())?, "max" => { if win.is_maximized().unwrap_or(false) { win.unmaximize() } else { win.maximize() }.map_err(|e|e.to_string())?; }, "close" => win.close().map_err(|e|e.to_string())?, _ => return Err("Acción de ventana desconocida".into()) }
            Ok(json!({"ok":true}))
        },
        "play" => Err("No se puede iniciar Minecraft todavía: falta implementar la descarga de bibliotecas/nativos, el perfil de versión y la autenticación oficial de Microsoft. No se ha iniciado ningún proceso.".into()),
        "mods:add" | "mods:install" | "mods:toggle" | "mods:del" | "mods:update" => Err("La gestión de archivos de mods aún no está implementada; no se ha modificado ningún archivo.".into()),
        "repair" => Err("La reparación automática de Minecraft aún no está implementada.".into()),
        "skin" | "capes:list" | "capes:set" => Err("Esta función requiere integrar el servicio oficial de perfiles de Minecraft.".into()),
        "open:ext" => {
            let url = args.get("url").and_then(Value::as_str).ok_or("Falta la URL")?;
            if !(url.starts_with("https://") || url.starts_with("http://")) { return Err("Solo se permiten enlaces HTTP o HTTPS".into()); }
            #[cfg(target_os = "windows")] std::process::Command::new("cmd").args(["/C", "start", "", url]).spawn().map_err(|e| e.to_string())?;
            #[cfg(target_os = "macos")] std::process::Command::new("open").arg(url).spawn().map_err(|e| e.to_string())?;
            #[cfg(all(unix, not(target_os = "macos")))] std::process::Command::new("xdg-open").arg(url).spawn().map_err(|e| e.to_string())?;
            Ok(json!({"ok":true}))
        },
        "app:restart" => Err("Reinicia Mellow Client desde Windows para aplicar los cambios.".into()),
        "partners:list" | "patchnotes" => Ok(json!([])),
        "logs:share" | "srv:cmd" | "srv:start" | "srv:stop" | "srv:open" | "srv:world" | "srv:pubip" => Err(format!("La operación '{}' todavía no está implementada.", command)),
        _ => Err(format!("Comando no reconocido: {}", command)),
    }
}
fn dirs_fallback() -> PathBuf {
    std::env::var_os("APPDATA").map(PathBuf::from).unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
}
fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![call])
        .run(tauri::generate_context!())
        .expect("error al iniciar Mellow Client");
}
