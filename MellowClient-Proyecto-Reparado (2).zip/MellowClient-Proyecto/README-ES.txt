MELLOW CLIENT — PROYECTO REPARADO / COMPILACIÓN WINDOWS
======================================================

Se ha reparado el punto de entrada de Rust, el puente JavaScript-Tauri y la
configuración de Tauri para exponer el API global. Se conserva la interfaz HTML.
El backend incluye guardado de configuración, listado local de mods JAR,
almacenamiento local de servidores y comandos de ventana.

IMPORTANTE: esto todavía NO es un launcher de Minecraft completo. La autenticación
Microsoft, descarga/instalación de versiones y bibliotecas, lanzamiento real del
juego, instalación/borrado de mods, reparación y alojamiento real de servidores
siguen pendientes. El programa devuelve errores explícitos para esas operaciones;
no simula que hayan funcionado. No introduzcas credenciales en una versión que no
implemente OAuth oficial.

COMPILAR EN WINDOWS
-------------------
Requisitos: Node.js 22, Rust estable (MSVC), Visual Studio Build Tools con C++ y
WebView2 Runtime.

1. Extrae el ZIP.
2. Abre PowerShell en la carpeta MellowClient-Proyecto.
3. Ejecuta: npm install
4. Ejecuta: npm run build

Los instaladores deberían aparecer en:
  src-tauri/target/release/bundle/nsis/
  src-tauri/target/release/bundle/msi/
El ejecutable de la aplicación debería aparecer en:
  src-tauri/target/release/mellow-client.exe

COMPILACIÓN AUTOMÁTICA
----------------------
Se añadió .github/workflows/build-windows.yml. Sube el proyecto a un repositorio
GitHub y abre Actions > Build Mellow Client for Windows > Run workflow. Al terminar,
descarga el artefacto MellowClient-Windows-x64.

La compilación no se ha ejecutado en este entorno: es Linux y no dispone de Rust
instalado ni de las herramientas de compilación de Windows. Por tanto, no se incluye
ningún .exe inventado ni se garantiza que la primera compilación pase sin ajustes.
